﻿namespace TH03_Kevin_William_Faith
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pSet = new System.Windows.Forms.Panel();
            this.tbSetor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnSetor = new System.Windows.Forms.Button();
            this.lblDep = new System.Windows.Forms.Label();
            this.pTar = new System.Windows.Forms.Panel();
            this.lbl_saldo2 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.tbTarik = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.btnTarik = new System.Windows.Forms.Button();
            this.pBal = new System.Windows.Forms.Panel();
            this.btnWith = new System.Windows.Forms.Button();
            this.lbl_saldo = new System.Windows.Forms.Label();
            this.btnDep = new System.Windows.Forms.Button();
            this.lblBal = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pReg = new System.Windows.Forms.Panel();
            this.lblPass = new System.Windows.Forms.Label();
            this.btnRegnew = new System.Windows.Forms.Button();
            this.lblUser = new System.Windows.Forms.Label();
            this.tbUserreg = new System.Windows.Forms.TextBox();
            this.tbPassreg = new System.Windows.Forms.TextBox();
            this.pLog = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.btnReg = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btnLog = new System.Windows.Forms.Button();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.tbPass = new System.Windows.Forms.TextBox();
            this.btnLogout = new System.Windows.Forms.Button();
            this.pSet.SuspendLayout();
            this.pTar.SuspendLayout();
            this.pBal.SuspendLayout();
            this.pReg.SuspendLayout();
            this.pLog.SuspendLayout();
            this.SuspendLayout();
            // 
            // pSet
            // 
            this.pSet.Controls.Add(this.tbSetor);
            this.pSet.Controls.Add(this.label6);
            this.pSet.Controls.Add(this.btnSetor);
            this.pSet.Controls.Add(this.lblDep);
            this.pSet.Location = new System.Drawing.Point(44, 194);
            this.pSet.Margin = new System.Windows.Forms.Padding(4);
            this.pSet.Name = "pSet";
            this.pSet.Size = new System.Drawing.Size(280, 197);
            this.pSet.TabIndex = 11;
            this.pSet.Visible = false;
            // 
            // tbSetor
            // 
            this.tbSetor.Location = new System.Drawing.Point(65, 85);
            this.tbSetor.Margin = new System.Windows.Forms.Padding(4);
            this.tbSetor.Name = "tbSetor";
            this.tbSetor.Size = new System.Drawing.Size(144, 22);
            this.tbSetor.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(111, 42);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 20);
            this.label6.TabIndex = 7;
            // 
            // btnSetor
            // 
            this.btnSetor.Location = new System.Drawing.Point(81, 127);
            this.btnSetor.Margin = new System.Windows.Forms.Padding(4);
            this.btnSetor.Name = "btnSetor";
            this.btnSetor.Size = new System.Drawing.Size(108, 34);
            this.btnSetor.TabIndex = 6;
            this.btnSetor.Text = "Deposit";
            this.btnSetor.UseVisualStyleBackColor = true;
            this.btnSetor.Click += new System.EventHandler(this.btnSetor_Click);
            // 
            // lblDep
            // 
            this.lblDep.AutoSize = true;
            this.lblDep.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDep.Location = new System.Drawing.Point(49, 42);
            this.lblDep.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDep.Name = "lblDep";
            this.lblDep.Size = new System.Drawing.Size(185, 20);
            this.lblDep.TabIndex = 1;
            this.lblDep.Text = "Input Deposit Amount : ";
            // 
            // pTar
            // 
            this.pTar.Controls.Add(this.lbl_saldo2);
            this.pTar.Controls.Add(this.label12);
            this.pTar.Controls.Add(this.lblBalance);
            this.pTar.Controls.Add(this.tbTarik);
            this.pTar.Controls.Add(this.label10);
            this.pTar.Controls.Add(this.label9);
            this.pTar.Controls.Add(this.btnTarik);
            this.pTar.Location = new System.Drawing.Point(44, 194);
            this.pTar.Margin = new System.Windows.Forms.Padding(4);
            this.pTar.Name = "pTar";
            this.pTar.Size = new System.Drawing.Size(280, 197);
            this.pTar.TabIndex = 12;
            this.pTar.Visible = false;
            // 
            // lbl_saldo2
            // 
            this.lbl_saldo2.AutoSize = true;
            this.lbl_saldo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saldo2.Location = new System.Drawing.Point(116, 22);
            this.lbl_saldo2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saldo2.Name = "lbl_saldo2";
            this.lbl_saldo2.Size = new System.Drawing.Size(0, 20);
            this.lbl_saldo2.TabIndex = 10;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(111, 42);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 20);
            this.label12.TabIndex = 7;
            // 
            // lblBalance
            // 
            this.lblBalance.AutoSize = true;
            this.lblBalance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.Location = new System.Drawing.Point(31, 22);
            this.lblBalance.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(85, 20);
            this.lblBalance.TabIndex = 9;
            this.lblBalance.Text = "Balance : ";
            // 
            // tbTarik
            // 
            this.tbTarik.Location = new System.Drawing.Point(63, 91);
            this.tbTarik.Margin = new System.Windows.Forms.Padding(4);
            this.tbTarik.Name = "tbTarik";
            this.tbTarik.Size = new System.Drawing.Size(144, 22);
            this.tbTarik.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(31, 62);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(210, 20);
            this.label10.TabIndex = 1;
            this.label10.Text = "Input Withdrawal Amount : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(108, 42);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 20);
            this.label9.TabIndex = 7;
            // 
            // btnTarik
            // 
            this.btnTarik.Location = new System.Drawing.Point(79, 128);
            this.btnTarik.Margin = new System.Windows.Forms.Padding(4);
            this.btnTarik.Name = "btnTarik";
            this.btnTarik.Size = new System.Drawing.Size(108, 34);
            this.btnTarik.TabIndex = 6;
            this.btnTarik.Text = "Withdraw";
            this.btnTarik.UseVisualStyleBackColor = true;
            this.btnTarik.Click += new System.EventHandler(this.btnTarik_Click);
            // 
            // pBal
            // 
            this.pBal.Controls.Add(this.btnWith);
            this.pBal.Controls.Add(this.lbl_saldo);
            this.pBal.Controls.Add(this.btnDep);
            this.pBal.Controls.Add(this.lblBal);
            this.pBal.Location = new System.Drawing.Point(44, 194);
            this.pBal.Margin = new System.Windows.Forms.Padding(4);
            this.pBal.Name = "pBal";
            this.pBal.Size = new System.Drawing.Size(280, 197);
            this.pBal.TabIndex = 13;
            this.pBal.Visible = false;
            // 
            // btnWith
            // 
            this.btnWith.Location = new System.Drawing.Point(81, 127);
            this.btnWith.Margin = new System.Windows.Forms.Padding(4);
            this.btnWith.Name = "btnWith";
            this.btnWith.Size = new System.Drawing.Size(108, 34);
            this.btnWith.TabIndex = 8;
            this.btnWith.Text = "Withdraw";
            this.btnWith.UseVisualStyleBackColor = true;
            this.btnWith.Click += new System.EventHandler(this.btnWith_Click);
            // 
            // lbl_saldo
            // 
            this.lbl_saldo.AutoSize = true;
            this.lbl_saldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saldo.Location = new System.Drawing.Point(111, 42);
            this.lbl_saldo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_saldo.Name = "lbl_saldo";
            this.lbl_saldo.Size = new System.Drawing.Size(0, 20);
            this.lbl_saldo.TabIndex = 7;
            // 
            // btnDep
            // 
            this.btnDep.Location = new System.Drawing.Point(81, 85);
            this.btnDep.Margin = new System.Windows.Forms.Padding(4);
            this.btnDep.Name = "btnDep";
            this.btnDep.Size = new System.Drawing.Size(108, 34);
            this.btnDep.TabIndex = 6;
            this.btnDep.Text = "Deposit";
            this.btnDep.UseVisualStyleBackColor = true;
            this.btnDep.Click += new System.EventHandler(this.btnDep_Click);
            // 
            // lblBal
            // 
            this.lblBal.AutoSize = true;
            this.lblBal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBal.Location = new System.Drawing.Point(19, 42);
            this.lblBal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBal.Name = "lblBal";
            this.lblBal.Size = new System.Drawing.Size(80, 20);
            this.lblBal.TabIndex = 1;
            this.lblBal.Text = "Balance :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 106);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 51);
            this.label1.TabIndex = 9;
            this.label1.Text = "UC BANK";
            // 
            // pReg
            // 
            this.pReg.Controls.Add(this.lblPass);
            this.pReg.Controls.Add(this.btnRegnew);
            this.pReg.Controls.Add(this.lblUser);
            this.pReg.Controls.Add(this.tbUserreg);
            this.pReg.Controls.Add(this.tbPassreg);
            this.pReg.Location = new System.Drawing.Point(44, 194);
            this.pReg.Margin = new System.Windows.Forms.Padding(4);
            this.pReg.Name = "pReg";
            this.pReg.Size = new System.Drawing.Size(280, 197);
            this.pReg.TabIndex = 14;
            this.pReg.Visible = false;
            // 
            // lblPass
            // 
            this.lblPass.AutoSize = true;
            this.lblPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPass.Location = new System.Drawing.Point(21, 78);
            this.lblPass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPass.Name = "lblPass";
            this.lblPass.Size = new System.Drawing.Size(93, 20);
            this.lblPass.TabIndex = 2;
            this.lblPass.Text = "Password :";
            // 
            // btnRegnew
            // 
            this.btnRegnew.Location = new System.Drawing.Point(81, 127);
            this.btnRegnew.Margin = new System.Windows.Forms.Padding(4);
            this.btnRegnew.Name = "btnRegnew";
            this.btnRegnew.Size = new System.Drawing.Size(108, 34);
            this.btnRegnew.TabIndex = 6;
            this.btnRegnew.Text = "Register";
            this.btnRegnew.UseVisualStyleBackColor = true;
            this.btnRegnew.Click += new System.EventHandler(this.btnRegnew_Click);
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUser.Location = new System.Drawing.Point(19, 42);
            this.lblUser.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(96, 20);
            this.lblUser.TabIndex = 1;
            this.lblUser.Text = "Username :";
            // 
            // tbUserreg
            // 
            this.tbUserreg.Location = new System.Drawing.Point(128, 41);
            this.tbUserreg.Margin = new System.Windows.Forms.Padding(4);
            this.tbUserreg.Name = "tbUserreg";
            this.tbUserreg.Size = new System.Drawing.Size(132, 22);
            this.tbUserreg.TabIndex = 3;
            // 
            // tbPassreg
            // 
            this.tbPassreg.Location = new System.Drawing.Point(128, 78);
            this.tbPassreg.Margin = new System.Windows.Forms.Padding(4);
            this.tbPassreg.Name = "tbPassreg";
            this.tbPassreg.Size = new System.Drawing.Size(132, 22);
            this.tbPassreg.TabIndex = 4;
            // 
            // pLog
            // 
            this.pLog.Controls.Add(this.label3);
            this.pLog.Controls.Add(this.btnReg);
            this.pLog.Controls.Add(this.label2);
            this.pLog.Controls.Add(this.btnLog);
            this.pLog.Controls.Add(this.tbUser);
            this.pLog.Controls.Add(this.tbPass);
            this.pLog.Location = new System.Drawing.Point(44, 194);
            this.pLog.Margin = new System.Windows.Forms.Padding(4);
            this.pLog.Name = "pLog";
            this.pLog.Size = new System.Drawing.Size(280, 197);
            this.pLog.TabIndex = 8;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 78);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password :";
            // 
            // btnReg
            // 
            this.btnReg.Location = new System.Drawing.Point(153, 127);
            this.btnReg.Margin = new System.Windows.Forms.Padding(4);
            this.btnReg.Name = "btnReg";
            this.btnReg.Size = new System.Drawing.Size(108, 34);
            this.btnReg.TabIndex = 6;
            this.btnReg.Text = "Register";
            this.btnReg.UseVisualStyleBackColor = true;
            this.btnReg.Click += new System.EventHandler(this.btnReg_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 42);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username :";
            // 
            // btnLog
            // 
            this.btnLog.Location = new System.Drawing.Point(23, 127);
            this.btnLog.Margin = new System.Windows.Forms.Padding(4);
            this.btnLog.Name = "btnLog";
            this.btnLog.Size = new System.Drawing.Size(108, 34);
            this.btnLog.TabIndex = 5;
            this.btnLog.Text = "Login";
            this.btnLog.UseVisualStyleBackColor = true;
            this.btnLog.Click += new System.EventHandler(this.btnLog_Click);
            // 
            // tbUser
            // 
            this.tbUser.Location = new System.Drawing.Point(128, 41);
            this.tbUser.Margin = new System.Windows.Forms.Padding(4);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(132, 22);
            this.tbUser.TabIndex = 3;
            // 
            // tbPass
            // 
            this.tbPass.Location = new System.Drawing.Point(128, 78);
            this.tbPass.Margin = new System.Windows.Forms.Padding(4);
            this.tbPass.Name = "tbPass";
            this.tbPass.Size = new System.Drawing.Size(132, 22);
            this.tbPass.TabIndex = 4;
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(156, 421);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 15;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Visible = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 472);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.pLog);
            this.Controls.Add(this.pReg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pBal);
            this.Controls.Add(this.pTar);
            this.Controls.Add(this.pSet);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pSet.ResumeLayout(false);
            this.pSet.PerformLayout();
            this.pTar.ResumeLayout(false);
            this.pTar.PerformLayout();
            this.pBal.ResumeLayout(false);
            this.pBal.PerformLayout();
            this.pReg.ResumeLayout(false);
            this.pReg.PerformLayout();
            this.pLog.ResumeLayout(false);
            this.pLog.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pSet;
        private System.Windows.Forms.TextBox tbSetor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnSetor;
        private System.Windows.Forms.Label lblDep;
        private System.Windows.Forms.Panel pTar;
        private System.Windows.Forms.Label lbl_saldo2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.TextBox tbTarik;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnTarik;
        private System.Windows.Forms.Panel pBal;
        private System.Windows.Forms.Button btnWith;
        private System.Windows.Forms.Label lbl_saldo;
        private System.Windows.Forms.Button btnDep;
        private System.Windows.Forms.Label lblBal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pReg;
        private System.Windows.Forms.Label lblPass;
        private System.Windows.Forms.Button btnRegnew;
        private System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox tbUserreg;
        private System.Windows.Forms.TextBox tbPassreg;
        private System.Windows.Forms.Panel pLog;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnReg;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnLog;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.TextBox tbPass;
        private System.Windows.Forms.Button btnLogout;
    }
}

