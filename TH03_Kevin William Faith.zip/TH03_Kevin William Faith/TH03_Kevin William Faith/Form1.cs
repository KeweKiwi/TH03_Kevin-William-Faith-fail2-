﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH03_Kevin_William_Faith
{
    public partial class Form1 : Form
    {
        DataTable dtBank = new DataTable();
        int input = 0;
        int cekregis = 0;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtBank.Columns.Add("Username");
            dtBank.Columns.Add("Password");
            dtBank.Columns.Add("Saldo");
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            pLog.Visible = false;
            pReg.Visible = true;
        }

        private void btnRegnew_Click(object sender, EventArgs e)
        {
            int cek = 0;
            for (int i = 0; i < dtBank.Rows.Count; i++)
            {
                if (dtBank.Rows[i][0].ToString() == tbUserreg.Text)
                {
                    cek++;
                }
            }
            if (cek == 0)
            {
                dtBank.Rows.Add(tbUserreg.Text, tbPassreg.Text, "0");
                MessageBox.Show("Register Succesful");
                cekregis++;
                tbUserreg.Text = ""; 
                tbPassreg.Text = "";
                pReg.Visible = false;
                pLog.Visible = true;
            }
            else if (cek > 0)
            {
                MessageBox.Show("Username has been used");
            }
        }

        private void btnLog_Click(object sender, EventArgs e)
        {
            if (cekregis == 0)
            {
                MessageBox.Show("YOU MUST REGISTER AN ACCOUNT FIRST!");
            }
            else
            {
                for (int i = 0; i < dtBank.Rows.Count; i++)
                {
                    if (dtBank.Rows[i][0].ToString() == tbUser.Text)
                    {
                        input = i;
                    }
                }
                if (dtBank.Rows[input][1].ToString() == tbPass.Text)
                {
                    MessageBox.Show("Login Succesful");
                    tbUser.Text = "";
                    tbPass.Text = "";
                    long rupiah = Convert.ToInt64(dtBank.Rows[input][2]);
                    lbl_saldo.Text = "Rp " + rupiah.ToString("N");
                    pLog.Visible = false;
                    pBal.Visible = true;
                    btnLogout.Visible = true;
                }
                else
                {
                    MessageBox.Show("Check your Username or Password");
                }
            }
        }

        private void btnDep_Click(object sender, EventArgs e)
        {
            pBal.Visible = false;
            pSet.Visible = true;
        }

        private void Setor(long a)
        {
            long saldo = Convert.ToInt64(dtBank.Rows[input][2]);
            if (a >= 1)
            {
                saldo = a + saldo;
                dtBank.Rows[input][2] = saldo;
                MessageBox.Show("Succesfully Add Deposit");
                tbSetor.Text = "";
                pSet.Visible = false;
                pBal.Visible = true;
            }
            else if (a < 1)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
        }
        private void Tarik(long b)
        {
            long saldo = Convert.ToInt64(dtBank.Rows[input][2]);
            if (b > saldo)
            {
                MessageBox.Show("Withdrawal Amount Can't be Larger than The Balance");
            }
            else if (b < 1)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else if (b <= saldo)
            {
                saldo = saldo - b;
                dtBank.Rows[input][2] = saldo;
                MessageBox.Show("Succesfully Withdraw");
                tbTarik.Text = "";
                pTar.Visible = false;
                pBal.Visible = true;
            }
        }
        private void btnSetor_Click(object sender, EventArgs e)
        {
            Setor(Convert.ToInt64(tbSetor.Text));
           long rupiah = Convert.ToInt64(dtBank.Rows [input][2]); 
                lbl_saldo.Text = "Rp " + rupiah.ToString("N");
        }

        private void btnWith_Click(object sender, EventArgs e)
        {
            pBal.Visible = false;
            long rupiah = Convert.ToInt64(dtBank.Rows[input][2]);
            lbl_saldo.Text = "Rp " + rupiah.ToString("N");
            pTar.Visible = true;
        }

        private void btnTarik_Click(object sender, EventArgs e)
        {
            Tarik(Convert.ToInt64(tbTarik.Text));
            long rupiah = Convert.ToInt64(dtBank.Rows[input][2]);
            lbl_saldo.Text = "Rp " + rupiah.ToString("N");
        }

        

        private void btnLogout_Click_1(object sender, EventArgs e)
        {
            pLog.Visible = true;
            pBal.Visible = false;
            pSet.Visible = false;
            pTar.Visible = false;
            btnLogout.Visible = false;
        }
    }
}
